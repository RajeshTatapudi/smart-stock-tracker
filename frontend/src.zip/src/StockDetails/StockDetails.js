function StockDetails(){
  return(
    <>
    Hello</>
  )
}